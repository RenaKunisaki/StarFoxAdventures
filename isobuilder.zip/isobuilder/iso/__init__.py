import struct
from .binaryfile import BinaryFile

class ISO:
    """Represents ISO file."""
